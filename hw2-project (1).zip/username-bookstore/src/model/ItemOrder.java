// Finish and comment me!

package model;

public final class ItemOrder {


    public ItemOrder(final Item theItem, final int theQuantity) {

    }


    public Item getItem() {
        
        return null;
    }
    
    public int getQuantity() {
        
        return 0;
    }


    @Override
    public String toString() {

        return null;
    }

}
